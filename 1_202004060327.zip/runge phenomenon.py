#利用拉格朗日插值法进行数据拟合，并针对函数：1/(1+x**2)，验证龙格现象，分析产生原理
#输入样本数据
# x_list = []#存放数据点的横坐标
# y_list = []
# while True:
#     x_list_value = input("请输入数据点的横坐标：xx。例如：2\n（输入end结束）")
#     if x_list_value == 'end' :
#         break
#     y_list_value = input("请输入数据点的纵坐标：xx。例如：2\n")
#     x_list.append(int(x_list_value))
#     y_list.append(int(y_list_value))
# print(x_list)
import numpy as np
import matplotlib.pyplot as plt
def lagrange(x_list,y_list,x):
    length=len(x_list)
    L_x = 0
    for i in range(length):
        fenzi = 1
        fenmu = 1
        for j in range(length):
            if j !=i:
                fenzi = fenzi * (x - x_list[j])
                fenmu = fenmu*(x_list[i]-x_list[j])
        L_x = L_x+y_list[i]*fenzi/fenmu
    return L_x
def y_true(x_train):
    y_train=[]
    for i in range(len(x_train)):
        y_train_value = 1/(1+(x_train[i])**2)
        y_train.append(y_train_value)
    return y_train
n=[4,6,8,10,12]
plt.figure(figsize=(8,6))
for i in range(5):
    x_train=np.linspace(-5,5,n[i])
    y_train=y_true(x_train)
    # print(y_train)
    # print(lagrange(x_train, y_train, 0))
    x_draw=np.linspace(-5,5,1000)
    y_draw=[]
    for j in range(1000):
        y_draw.append(lagrange(x_train,y_train,x_draw[j]))
    plt.plot(x_draw,y_draw,lw=1,label="n=%d"%(2*i+4))
x=np.linspace(-5,5,1000)
y=y_true(x)
plt.plot(x,y,'--b',lw=2,label=r"$\frac{1}{1 + x^{2}}\qquad$")
plt.legend(bbox_to_anchor=(0.7,0.65))
plt.show()


# plt.scatter(x_train, y_train)
# plt.show()

