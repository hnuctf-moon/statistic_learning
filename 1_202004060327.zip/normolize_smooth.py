#利用插值法对数据进行标准化，将不同规格的数据，统一到统一规格后求取平均值，并可以利用平均滑动进行平滑处理
#获取数据源
import xlrd
worksheet = xlrd.open_workbook("data.xls")
sheet_name = worksheet.sheet_names()[0]
# print(type(sheet_names),'1')
# for sheet_name in sheet_names:
sheet = worksheet.sheet_by_name(sheet_name)
rows = sheet.nrows
cols = sheet.ncols
list1 = sheet.col_values(0)
list2 = sheet.col_values(1)
list3 = sheet.col_values(2)
list1 = [i for i in list1 if i !='']
list2 = [i for i in list2 if i !='']
list3 = [i for i in list3 if i !='']
# while '' in list1:
#     list1.remove('')
# while '' in list2:
#     list1.remove('')
# while '' in list3:
#     list1.remove('')
# print(list1)
# print(list2)
# print(list3)
# from openpyxl import workbook
# wb=workbook()
# sheet=wb.active
import numpy as np
import math
#定义标准化函数
def normalize(list,num):
    x_0=np.linspace(1,len(list),len(list))
    x_1=np.linspace(1,len(list),num)
    list_n=[]
    for i in range(num):
        if 0<i<num-1:
            a=math.floor(x_1[i])
            x0=[0,0]
            y0=[0,0]
            x0[0]=x_0[a-1]
            y0[0]=list[a-1]
            x0[1]=x_0[a]
            y0[1]=list[a]
            x=x_1[i]
            y=(y0[1]-y0[0])*(x-x0[0])/(x0[1]-x0[0])+y0[0]
            list_n.append(y)
        elif i==0:
            list_n.append(list[0])
        else:
            list_n.append(list[-1])
    return list_n
list1_nor=normalize(list1,2000)
list2_nor=normalize(list2,2000)
list3_nor=normalize(list3,2000)
#求平均值
list_a=[]
for i in range(2000):
    average_value=(list1_nor[i]+list2_nor[i]+list3_nor[i])/3
    list_a.append(average_value)
#定义平滑函数
def smooth(list,window_size):
    length=len(list)
    list_s=[]
    for i in range(1,length+1):
        if window_size < i < length-window_size:
            value_total=0
            for j in range(2*window_size+1):
                value_total=value_total+list[i-window_size+j]
            list_s.append(value_total/(2*window_size+1))
        elif i<=window_size:
            # list_s.append(list[i-1])
            value_total=0
            for m in range(2*i-1):
                value_total = value_total + list[m]
            list_s.append(value_total / (2 * i - 1))
        else:
            # list_s.append(list[i-1])
            value_total = 0
            for n in range(2 * (length-i)+1):
                value_total = value_total + list[i-(length-i)+n-1]
            list_s.append(value_total / (2 * (length-i) + 1))
    return list_s
list_a_s = smooth(list_a,100)
#画图展示
import matplotlib.pyplot as plt
plt.figure(figsize=(8,6))
x=np.linspace(1,2000,2000)
plt.plot(x,list_a,lw=2,label='average')
plt.plot(x,list_a_s,lw=2,label='smooth')
plt.legend()
plt.show()